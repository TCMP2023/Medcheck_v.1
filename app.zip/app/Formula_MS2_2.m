%% PART 2 每个母离子挑前三强子离子
tic
%% 输入二级数据原始文件.msp和上一步输出的excel；输出结果为results.cell，需手动处理

% rawdata = table2cell(readtable("DGJZT_MS2_formula_name_pos_neg.xlsx"));%按模板整理每个复方的药味及路径信息，一次只放一个复方，正负离子模式放在一个表不同列;原始数据命名时需标记pos和neg
%appreadexcel="DGJZT_MS2_formula_name_pos_neg.xlsx";
rawdata = table2cell(readtable(appreadexcel));


%% 创建一个存储处理结果的文件夹
if ~exist('result2','file')
    mkdir('result2')
end

% %% 修改文件名
% for i = 1:length(rawdata)
%     % 修改第2列
%     newStr2=split(rawdata(i,2),'C:\Users\z820\Desktop\lxl-bxxxt\20230208\bxxxt');
%     newStr2(1,:) = [];
%     temp2 = strcat(pwd,newStr2);
%     rawdata(i,2) = temp2;
%     % 修改第3列
%     newStr3=split(rawdata(i,3),'C:\Users\z820\Desktop\lxl-bxxxt\20230208\bxxxt');
%     newStr3(1,:) = [];
%     temp3 = strcat(pwd,newStr3);
%     rawdata(i,3) = temp3;
%         % 修改第4列
%     newStr4=split(rawdata(i,4),'C:\Users\z820\Desktop\lxl-bxxxt\20230225-7f-pos-neg\DGJZT\+\MS2');
%     newStr4(1,:) = [];
%     temp4 = strcat(pwd,newStr4);
%     rawdata(i,4) = temp4;
%         % 修改第5列
%     newStr5=split(rawdata(i,5),'C:\Users\z820\Desktop\lxl-bxxxt\20230225-7f-pos-neg\DGJZT\-\MS2');
%     newStr5(1,:) = [];
%     temp5 = strcat(pwd,newStr5);
%     rawdata(i,5) = temp5;
% end

MSP_rt_mz = [];
% delta_rt = 0.1; %% min
% delta_mz = 10; %% ppm
for m = 1:size(rawdata,1)
    for n = 1:2
        if n < 2
            clear MSP
            sample_m = char(rawdata(m,1));
            pathway_MS1 = char(rawdata(m,2));
            pathway_MS2 = char(rawdata(m,4));
            eval(['TCM_',sample_m,'_MS1 = table2array(readtable("',pathway_MS1,'"));']); %读入一级结果
            eval(['TCM_',sample_m,'_MS2 = MSP_reader_QI("',pathway_MS2,'");']); %读入二级原始数据
            eval(['MSP = TCM_',sample_m,'_MS2;']);
            
            MSP_rt_mz = [];
            for i = 1:size(MSP.scan,1)%zgc的第二针二级里打了135个母离子的碎片;%1表示行数，2表示列数
                MSP_Commenti = MSP.scan(i).Comment;
                index1 = find(MSP_Commenti=='_');
                MSP_rt_mz(i,1) = str2double(MSP_Commenti(1:index1-1));%提取保留时间
                MSP_rt_mz(i,2) = MSP.scan(i).PrecursorMZ;%提取二级文件中的一级质荷比
            end
            
            if  eval(['size(TCM_',sample_m,'_MS1,2)<9'])%isempty (MS1)
                eval(['fprintf("this file: TCM_',sample_m,'_MS1 is empty.\n");']);
                eval(['xlswrite(["result2\TCM_',sample_m,'_POS_ms2_results.xlsx"],TCM_',sample_m,'_MS1);']);%0630
            else
                MS1 = [];
                eval(['MS1 = TCM_',sample_m,'_MS1(:,1:2);']);%将变化的结果存在不用变的MS1中，简化代码
                results = {};
                results = num2cell(MS1);%将MS1的质荷比和保留时间转移到二级结果中
                
                for i = 1:size(MS1,1)%只能在MS1中循环，不能在results中，因为results为cell，不能用于计算，只用于储存结果
                    rti = MS1(i,2);
                    mzi = MS1(i,1);
                    indexi = find(abs(rti-MSP_rt_mz(:,1)) <= delta_rt & (abs(mzi-MSP_rt_mz(:,2))/mzi*1000000) <= delta_mz);
                    if size(indexi,1) > 0
                        results{i,3} = indexi;%返回在二级中匹配上的序列号
                        for j = 1:size(indexi,1)%在匹配上的这几个二级序号中循环
                            indexj = indexi(j,1);
                            ms2i = MSP.scan(indexj).MS2Data;
                            indexd = find(ms2i(:,1) > mzi-12.9);%将当前二级数据中M/Z大于母离子减去12.9da的离子全部删除
                            ms2i(indexd,:) = [];%将不能解释的碎片删掉（至少脱一个CH）
                            %%在二级数据中寻找响应前三强的子离子
                            %第一强
                            if size(ms2i,1)>1 %如果这个母离子打到了二级
                                top1_index = find(ms2i(:,2) == max(ms2i(:,2)));%找最大的那个子离子
                                if size(top1_index,1) > 1%如果找到了多个
                                    top1_index(2:end,:) = [];%取质荷比比较小的那个，质荷比较大的那个就会变成第二强子离子
                                end
                                top1_ms2 = ms2i(top1_index,1);
                                top1_abs = ms2i(top1_index,2);
                                results{i,4}(j,1) = top1_ms2; results{i,5}(j,1) = top1_abs;
                                ms2i(top1_index,:) = [];
                            else
                                results{i,4}(j,1) = 0; results{i,5}(j,1) = 0;
                            end
                            %第二强
                            if size(ms2i,1)>1
                                top2_index = find(ms2i(:,2) == max(ms2i(:,2)));
                                if size(top2_index,1) > 1
                                    top2_index(2:end,:) = [];
                                end
                                top2_ms2 = ms2i(top2_index,1);
                                top2_abs = ms2i(top2_index,2);
                                results{i,6}(j,1) = top2_ms2; results{i,7}(j,1) = top2_abs;
                                ms2i(top2_index,:) = [];
                            else
                                results{i,6}(j,1) = 0; results{i,7}(j,1) = 0;
                            end
                            %第三强
                            if size(ms2i,1)>1
                                top3_index = find(ms2i(:,2) == max(ms2i(:,2)));
                                if size(top3_index,1) > 1
                                    top3_index(2:end,:) = [];
                                end
                                top3_ms2 = ms2i(top3_index,1);
                                top3_abs = ms2i(top3_index,2);
                                results{i,8}(j,1) = top3_ms2; results{i,9}(j,1) = top3_abs;
                            else
                                results{i,8}(j,1) = 0; results{i,9}(j,1) = 0;
                            end
                        end
                    else
                        results{i,3} = 0; results{i,4} = 0;  results{i,5} = 0;
                        results{i,6} = 0; results{i,7} = 0;  results{i,8} = 0; results{i,9} = 0;
                    end
                    results{i,10} = [char(rawdata(m,1)),'_',num2str(i)];
                end
                %导出之前先把前三强离子列成一列
                results_1 = [];results_2 = [];results_3 = [];results_name = [];
                results_1 = results(:,[1:3,4:5]);
                results_2 = results(:,[1:3,6:7]);
                results_3 = results(:,[1:3,8:9]);
                results_name = results(:,10);
                MS2_results = {};
                MS2_results(:,2:6) = [results_1;results_2;results_3];
                
                for k =1:size(MS2_results,1)%名字加进去
                    if k <= size(results_1,1)
                        MS2_results{k,1} =  [char(results_name(k,1)),'_1_POS'];
                    elseif k > 2*size(results_1,1)
                        MS2_results{k,1} =  [char(results_name(k-2*size(results_1,1),1)),'_3_POS'];
                    else
                        MS2_results{k,1} =  [char(results_name(k-size(results_1,1),1)),'_2_POS'];
                    end
                end
                %                 eval(['xlswrite(["result\TCM_',TCM_Taget,'_POS_ms1_results.xlsx"],TCM_formula_file)']);
                
                eval(['xlswrite(["result2\TCM_',sample_m,'_POS_ms2_results.xlsx"],MS2_results);']);%0630
            end
    else
                clear MSP
                sample_m = char(rawdata(m,1));
                pathway_MS1 = char(rawdata(m,3));
                pathway_MS2 = char(rawdata(m,5));
                eval(['TCM_',sample_m,'_MS1 = table2array(readtable("',pathway_MS1,'"));']); %读入
                eval(['TCM_',sample_m,'_MS2 = MSP_reader_QI("',pathway_MS2,'");']); %读入
                eval(['MSP = TCM_',sample_m,'_MS2;']);
                
                MSP_rt_mz = [];
                for i = 1:size(MSP.scan,1)%zgc的第二针二级里打了135个母离子的碎片;%1表示行数，2表示列数
                    MSP_Commenti = MSP.scan(i).Comment;
                    index1 = find(MSP_Commenti=='_');
                    MSP_rt_mz(i,1) = str2double(MSP_Commenti(1:index1-1));
                    MSP_rt_mz(i,2) = MSP.scan(i).PrecursorMZ;
                end
                if  eval(['size(TCM_',sample_m,'_MS1,2)<9'])%如果有一个特征母离子，则至少有9列数据，否则说明MS1匹配时一个母离子都没找到
                    eval(['fprintf("this file: TCM_',sample_m,'_MS1_neg is empty.\n");']);
                    eval(['xlswrite(["result2\TCM_',sample_m,'_POS_ms2_results.xlsx"],TCM_',sample_m,'_MS1);']);%0630修改
                else
                    MS1 = [];
                    eval(['MS1 = TCM_',sample_m,'_MS1(:,1:2);']);%将变化的结果存在不用变的MS1中，简化代码
                    results = {};
                    results = num2cell(MS1);%将MS1的质荷比和保留时间转移到二级结果中
                    
                    for i = 1:size(MS1,1)%只能在MS1中循环，不能在results中，因为results为cell，不能用于计算，只用于储存结果
                        rti = MS1(i,2);
                        mzi = MS1(i,1);
                        indexi = find(abs(rti-MSP_rt_mz(:,1)) <= delta_rt & (abs(mzi-MSP_rt_mz(:,2))/mzi*1000000) <= delta_mz);
                        
                        if size(indexi,1) > 0
                            results{i,3} = indexi;%返回在二级中匹配上的序列号
                            for j = 1:size(indexi,1)%在匹配上的这几个二级序号中循环
                                indexj = indexi(j,1);
                                ms2i = MSP.scan(indexj).MS2Data;
                                indexd = find(ms2i(:,1) > mzi-12.9);%将当前二级数据中M/Z大于母离子减去12.9da的离子全部删除
                                ms2i(indexd,:) = [];%将不能解释的碎片删掉（至少脱一个CH）
                                %%在二级数据中寻找响应前三强的子离子
                                %第一强
                                if size(ms2i,1)>1 %如果这个母离子打到了二级
                                    top1_index = find(ms2i(:,2) == max(ms2i(:,2)));%找最大的那个子离子
                                    if size(top1_index,1) > 1%如果找到了多个
                                        top1_index(2:end,:) = [];%取质荷比比较小的那个，质荷比较大的那个就会变成第二强子离子
                                    end
                                    top1_ms2 = ms2i(top1_index,1);
                                    top1_abs = ms2i(top1_index,2);
                                    results{i,4}(j,1) = top1_ms2; results{i,5}(j,1) = top1_abs;
                                    ms2i(top1_index,:) = [];
                                else
                                    results{i,4}(j,1) = 0; results{i,5}(j,1) = 0;
                                end
                                %第二强
                                if size(ms2i,1)>1
                                    top2_index = find(ms2i(:,2) == max(ms2i(:,2)));
                                    if size(top2_index,1) > 1
                                        top2_index(2:end,:) = [];
                                    end
                                    top2_ms2 = ms2i(top2_index,1);
                                    top2_abs = ms2i(top2_index,2);
                                    results{i,6}(j,1) = top2_ms2; results{i,7}(j,1) = top2_abs;
                                    ms2i(top2_index,:) = [];
                                else
                                    results{i,6}(j,1) = 0; results{i,7}(j,1) = 0;
                                end
                                %第三强
                                if size(ms2i,1)>1
                                    top3_index = find(ms2i(:,2) == max(ms2i(:,2)));
                                    if size(top3_index,1) > 1
                                        top3_index(2:end,:) = [];
                                    end
                                    top3_ms2 = ms2i(top3_index,1);
                                    top3_abs = ms2i(top3_index,2);
                                    results{i,8}(j,1) = top3_ms2; results{i,9}(j,1) = top3_abs;
                                else
                                    results{i,8}(j,1) = 0; results{i,9}(j,1) = 0;
                                end
                            end
                        else
                            results{i,3} = 0; results{i,4} = 0;  results{i,5} = 0;
                            results{i,6} = 0; results{i,7} = 0;  results{i,8} = 0; results{i,9} = 0;
                        end
                        results{i,10} = [char(rawdata(m,1)),'_',num2str(i)];
                    end
                    %导出之前先把前三强离子列成一列
                    results_1 = [];results_2 = [];results_3 = [];results_name = [];
                    results_1 = results(:,[1:3,4:5]);
                    results_2 = results(:,[1:3,6:7]);
                    results_3 = results(:,[1:3,8:9]);
                    results_name = results(:,10);
                    MS2_results = {};
                    MS2_results(:,2:6) = [results_1;results_2;results_3];
                    
                    for k =1:size(MS2_results,1)%名字加进去
                        if k <= size(results_1,1)
                            MS2_results{k,1} =  [char(results_name(k,1)),'_1_NEG'];
                        elseif k > 2*size(results_1,1)
                            MS2_results{k,1} =  [char(results_name(k-2*size(results_1,1),1)),'_3_NEG'];
                        else
                            MS2_results{k,1} =  [char(results_name(k-size(results_1,1),1)),'_2_NEG'];
                        end
                    end
                    
                    eval(['xlswrite(["result2\TCM_',sample_m,'_NEG_ms2_results.xlsx"],MS2_results);']); %0630修改
                end
            end
        end
end


clear delta_rt delta_mz i index1 indexd indexi indexj j k MSP_Commenti mzi rti
clear MS1 MS2_results  ms2i 
clear pathway_MS1 pathway_MS2 results_1 results_2 results_3 
clear results_name sample_m 
clear top1_abs top1_index top1_ms2 top2_abs top2_index top2_ms2 top3_abs top3_index top3_ms2


T=toc;







