function [mgfStruct] = MSP_reader_QI(file)
% Validate file
ismsp(file);

% Default structure for data storage
defaultStruct = struct('Name',[],...
    'PrecursorMZ',[],...
    'CHARGE',[],...
    'Comment',[],...
    'Num_Peaks',[],...
    'MS2Data',[]);

fprintf('Reading file\n');
% Open and read .MGF file

fileID = fopen(file,'r');  %fileID = fopen(filename) 打开文件 filename 以便以二进制读取形式进行访问，并返回等于或大于 3 的整数文件标识符 
fileData = [];
fileData = textscan(fileID,'%s'); %打开file,msp数据就保存在fileData文件中
%  %s按空格分段
fileData = fileData{1,1};
fclose(fileID);

% Get total number of scans
scanCount = numel(find(contains(fileData,'Name')));%%通过扫描'Name'字符，确定mgf文件中含有多少个二级文件
mgfStruct.scan = repmat(defaultStruct,scanCount,1); %%通过scanCount值将defaultStruct的维度进行repmat
%将defaultstructure 按扫描数重复，并保存在scan中
fprintf('Number of MS/MS scans: %d\n',scanCount);

BeginRow = find(contains(fileData,'Name'));
EndRow = find(contains(fileData,'Name'))-1;
EndRow(1) = []; EndRow(end+1) = size(fileData,1);
for i = 1:length(BeginRow)
    MSP_scan = fileData(BeginRow(i):EndRow(i),1);
    if sum(contains(MSP_scan,'Charge:'))== 1   %%如果文件中含有字符CHARGE=，则采取以下操作
        % Get Name
        NameRow = find(contains(MSP_scan,'Name:'));
        mgfStruct.scan(i).Name = MSP_scan{NameRow+2,1};%在filedata里面name后一行是unknown，后2行是'(0.81_666.2237n)'
        % Get precursor mass
        precursorRow = find(contains(MSP_scan,'PrecursorMZ:'));
        mgfStruct.scan(i).PrecursorMZ = str2double(MSP_scan{precursorRow+1,1});
        % Get Charge: CHARGE
        chargeRow = find(contains(MSP_scan,'Charge:'));
        mgfStruct.scan(i).CHARGE = MSP_scan{chargeRow+1,1};
        % Get Comment
        CommentRow = find(contains(MSP_scan,'Comment:'));
        mgfStruct.scan(i).Comment = MSP_scan{CommentRow+1,1};
        % Get Num Peaks
        Num_PeaksRow = find(contains(MSP_scan,'Peaks:'));
        mgfStruct.scan(i).Num_Peaks = str2double(MSP_scan{Num_PeaksRow+1,1}); 
        % Get MS2 data 
        tempMS = str2double(MSP_scan(Num_PeaksRow+2:end,1)); %用{}？？
        tempMZ = tempMS(1:2:end);
        tempINT = tempMS(2:2:end);
        tempScan = [tempMZ,tempINT];
        mgfStruct.scan(i).MS2Data = tempScan; 
    else
        % Get Name
        NameRow = find(contains(MSP_scan,'Name:'));
        mgfStruct.scan(i).Name = MSP_scan{NameRow+2,1};
        % Get precursor mass
        precursorRow = find(contains(MSP_scan,'PrecursorMZ:'));
        mgfStruct.scan(i).PrecursorMZ = str2double(MSP_scan{precursorRow+1,1});
        % Get Charge: CHARGE
        mgfStruct.scan(i).CHARGE = '0';
        % Get Comment
        CommentRow = find(contains(MSP_scan,'Comment:'));
        mgfStruct.scan(i).Comment = MSP_scan{CommentRow+1,1};
        % Get Num Peaks
        Num_PeaksRow = find(contains(MSP_scan,'Peaks:'));
        mgfStruct.scan(i).Num_Peaks = str2double(MSP_scan{Num_PeaksRow+1,1}); 
        % Get MS2 data 
        tempMS = str2double(MSP_scan(Num_PeaksRow+2:end,1)); 
        tempMZ = tempMS(1:2:end);
        tempINT = tempMS(2:2:end);
        tempScan = [tempMZ,tempINT];
        mgfStruct.scan(i).MS2Data = tempScan; 
    end
    if rem(i, floor(length(BeginRow)/20)) == 0
    disp(['The completion ratio is: ',num2str(i*100/length(BeginRow)),'%']);
    elseif i == length(BeginRow)
    disp(['The completion ratio is: ','100%']);
    end   
end
fprintf('Finished!\n');
end


function ismsp(files)   
    if ~iscell(files) %%判断给定数组是否是元胞数组
        tf = ~isempty(contains(files,'msp'));%%判断文件名中是否含有msp后缀
        if tf == true
            fprintf('File type: .msp\n');
        else
            error('File type is not .msp');
        end
    else
        for p = 1:length(files)
            tf = ~isempty(contains(files{p},'msp'));
            if tf == true
                fprintf('File %d. Type is .msp\n',p);
            else
                error(sprintf('File %d. Type is not .msp',p));
            end
        end
    end  
end



