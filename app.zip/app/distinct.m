function result = distinct(DATA,delat_RT,delta_MZ)
for i = 1:size(DATA,1)
    mz = DATA(i,1); rt = DATA(i,2);
    index = find(abs(mz-DATA(:,1))/mz*1000000 <= delta_MZ & abs(rt-DATA(:,2)) <= delat_RT);
    if size(index,1)==1
       DATA(i,4)=1;
    else
       ii = find(DATA(index,3) == max(DATA(index,3)));
       DATA(index(ii),4)=1;
       index(ii,:) = [];
       DATA(index,4)=0;
    end
end
%%删除重复数据
DATA(DATA(:,4)==0,:) = [];
DATA(:,4) = [];
result = DATA;

























